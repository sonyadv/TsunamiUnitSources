%nc_dump('japan311_2_source001_runupA_ha.nc');
clc; clear; fclose all; close all;

%% 檔名
mostname = 'japan311_2GridC.most';
ncname = 'japan311_2_source001_runup_ha.nc';
name = 'GridC';

%% 讀地形檔
mostFn = dlmread(mostname);

% 前處理
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% most format：                                                           %
%                                                                         %
% 1      nodes(y) nodes(x)                                                %
% 2      lon                                                              %
% y+2    lat                                                              %
% x+y+2 ... y                                                             %
% :                                                                       %
% :      bathymetry                                                       %
% :                                                                       %
% x+y+1+x                                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

y = mostFn(1,1);
x = mostFn(1,2);
lon = mostFn(2:y+1,1);
lat = mostFn(y+2:x+y+1,1);
bath = mostFn(x+y+2:x+y+1+x,1:y);
bath = bath.*-1;
[Lon,Lat] = meshgrid(lon,lat);

% 畫圖
figure(1)
plot = pcolor(Lon,Lat,bath);                                              % 畫地形圖
set(plot, 'EdgeColor', 'none');                                           % pcolor不要網格
shading flat; axis image;                                                 % 顏色設定
hold on
contour(Lon,Lat,bath,[0 0],'k');                                          % 畫海岸線
box on; grid on; set(gca, 'layer', 'top');                                % 經緯度格線、放到最上面
hcb = colorbar; set(get(hcb,'Ylabel'),'String','Elevation (m)');          % colorbar顯示、標題設定
xlabel('Longitude'); ylabel('Latitude');                                  % 坐標軸標題
title([name ' topographic map'])                                          % 圖標題
print([name '_topographicMap.png'],'-dpng','-r600');                      % 印出dpi600的png

%% 讀 runup
ts=nc_varget(ncname, 'TIME');
ha=nc_varget(ncname,'HA');

% 前處理
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% runup.nc format:                                                        %
%                                                                         %
% dimensions:                                                             %
%   LON = x ;                                                             %
%	LAT = y ;                                                             %
%	TIME(sec) = UNLIMITED ;                                               %
%                                                                         %
% variables:                                                              %
%     single VA(TIME,LAT,LON), shape = [t x y]                            %
%         VA:units = "CENTIMETERS/SECOND" ;                               %
%         VA:long_name = "Velocity Component along Latitude" ;            %
%     single UA(TIME,LAT,LON), shape = [t x y]                            %
% 		  UA:units = "CENTIMETERS/SECOND" ;                               %
% 		  UA:long_name = "Velocity Component along Longitude" ;           %
% 	  single HA(TIME,LAT,LON), shape = [t x y]                            %
% 		  HA:long_name = "Wave Amplitude" ;                               %
% 	      HA:units = "CENTIMETERS" ;                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[x y] = size(Lon);
wave = ha(1,:,:);
wave = reshape(wave,x,y);

% 畫圖
figure(2)
plot = pcolor(Lon,Lat,wave);                                              % 畫地形圖
set(plot, 'EdgeColor', 'none');                                           % pcolor不要網格
caxis([-1000 1000])                                                       % 範圍設定
cmap = cbrewer2('RdBu');                                                  % 色階設定
colormap(flip(cmap));                                                     % 反正就是那個紅紅藍藍的
shading flat; axis image;                                                 % 顏色設定
hold on
contour(Lon,Lat,bath,[0 0],'k');                                          % 畫海岸線
box on; grid on; set(gca, 'layer', 'top');                                % 經緯度格線、放到最上面
hcb = colorbar; set(get(hcb,'Ylabel'),'String','wave height (m)');        % colorbar顯示、標題設定
xlabel('Longitude'); ylabel('Latitude');                                  % 坐標軸標題
title([name ' initial surface'])                                          % 圖標題
print([name '_initialSurface.png'],'-dpng','-r600');                      % 印出dpi600的png